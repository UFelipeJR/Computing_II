#ifndef UNIDAD1_H
#define UNIDAD1_H

// Ejercicios

void ejercicio1();
void ejercicio2();
void ejercicio3();
void ejercicio4();
void ejercicio5();
void ejercicio6();
void ejercicio7();
void ejercicio8();
void ejercicio9();
void ejercicio10();
void ejercicio11();
void ejercicio12();
void ejercicio13();
void ejercicio14();
void ejercicio15();
void ejercicio16();
void ejercicio17();
void ejercicio18();
void ejercicio19();
void ejercicio20();
void ejercicio21();
void ejercicio22();
void ejercicio23();
void ejercicio24();
void ejercicio25();
void ejercicio26();
void ejercicio27();
void ejercicio28();
void ejercicio29();
void ejercicio30();

//Problemas

void problema1();
void problema2();
void problema3();
void problema4();
void problema5();
void problema6();
void problema7();
void problema8();
void problema9();
void problema10();
void problema11();
void problema12();
void problema13();
void problema14();
void problema15();
void problema16();
void problema17();

//Funciones con retorno
int esPrimo(int);
int mcm(int,int);
bool esPalindrome(int);
int lenCollatz(int);


//Menú
void menuPrincipal();
void ejercicios();
void problemas();

#endif // UNIDAD1_H
